WARNING: Only have one HBA installed at a time to use the script files.
This will not preserve the SAS address, it will generate a new random one.
This simplified the entire process and eliminates flashing differences between H200 and H310.

Dell H310/H200 Auto-flash to LSI IT Mode.
1. Format USB drive as FreeDOS with RuFus
2. Extract archive to USB drive, overwrite everything
3. Boot in BIOS boot mode
4. Run 1 batch file, the computer will reboot twice.
5. Press yes to the NVRAM Product ID mismatch, this is normal.
6. Only run 4_bios/4_efi if you want to make the card bootable. This can be done later at any time, it will also increase your boot time significantly.



